## Reconstruction of image using SVD and EVD

# Makefile is created for simplicity

- make run JOB=<job_type> 
    - executes the code, job_type can be svd, evd or all 
- make clean 
    - cleans the output